import React, {useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const halls = [
  {id:1,name:"Grand Palace Hall",capacity:800,rent:85000},
  {id:2,name:"Royal Celebration Hall",capacity:500,rent:60000},
  {id:3,name:"Pearl Mini Hall",capacity:300,rent:40000}
];

const foods = [
  {id:1,type:"Veg",name:"Premium Veg Meals",price:300},
  {id:2,type:"Veg",name:"Paneer Special",price:350},
  {id:3,type:"Veg",name:"Veg Biryani",price:220},
  {id:4,type:"Non-Veg",name:"Chicken Biryani",price:330},
  {id:5,type:"Non-Veg",name:"Chicken 65",price:300},
  {id:6,type:"Non-Veg",name:"Mutton Special",price:450}
];

function App(){
  const [data,setData] = useState({
    customer:"", phone:"", email:"", event:"Marriage",
    date:"", guests:100, hall:1, food:1, payment:"UPI"
  });
  const [result,setResult] = useState("");

  const hall = halls.find(x=>x.id===Number(data.hall));
  const food = foods.find(x=>x.id===Number(data.food));
  const total = hall.rent + Number(data.guests)*food.price;

  const change=e=>setData({...data,[e.target.name]:e.target.value});

  async function submit(e){
    e.preventDefault();
    try{
      const res=await fetch("http://localhost:5000/api/bookings",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({...data,total})
      });
      const json=await res.json();
      if(!res.ok) throw new Error(json.message);
      setResult(`Booking confirmed! ID: ${json.bookingId} | Total: ₹${total.toLocaleString("en-IN")} | Payment: ${json.paymentStatus}`);
    }catch(err){
      setResult("Backend is not running. Start the Node.js server first.");
    }
  }

  return <div>
    <header>
      <h1>Royal Celebrations</h1>
      <p>Complete Online Function Hall Booking</p>
    </header>

    <main>
      <div className="halls">
        {halls.map(h=><div className="hall" key={h.id}>
          <h2>{h.name}</h2>
          <p>Capacity: {h.capacity} guests</p>
          <b>Hall Rent: ₹{h.rent.toLocaleString("en-IN")}</b>
        </div>)}
      </div>

      <form onSubmit={submit}>
        <h2>Booking Details</h2>
        <div className="grid">
          <input name="customer" placeholder="Customer Name" required value={data.customer} onChange={change}/>
          <input name="phone" placeholder="10-digit Phone" pattern="[0-9]{10}" required value={data.phone} onChange={change}/>
          <input name="email" type="email" placeholder="Email" required value={data.email} onChange={change}/>
          <select name="event" value={data.event} onChange={change}>
            <option>Marriage</option><option>Birthday</option><option>Reception</option><option>Engagement</option><option>Corporate Event</option>
          </select>
          <input name="date" type="date" required value={data.date} onChange={change}/>
          <input name="guests" type="number" min="10" max={hall.capacity} required value={data.guests} onChange={change}/>
          <select name="hall" value={data.hall} onChange={change}>
            {halls.map(h=><option value={h.id} key={h.id}>{h.name} — ₹{h.rent.toLocaleString("en-IN")}</option>)}
          </select>
          <select name="food" value={data.food} onChange={change}>
            {foods.map(f=><option value={f.id} key={f.id}>{f.type} — {f.name} — ₹{f.price}/person</option>)}
          </select>
          <select name="payment" value={data.payment} onChange={change}>
            <option>UPI</option><option>Card</option><option>Net Banking</option><option>Cash at Hall</option>
          </select>
        </div>

        <section className="summary">
          <p>Hall: ₹{hall.rent.toLocaleString("en-IN")}</p>
          <p>{food.type} Food: ₹{(Number(data.guests)*food.price).toLocaleString("en-IN")}</p>
          <h2>Total: ₹{total.toLocaleString("en-IN")}</h2>
        </section>

        <button>Confirm Booking</button>
        {result && <div className="result">{result}</div>}
      </form>
    </main>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);
