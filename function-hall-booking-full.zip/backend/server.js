import express from "express";
import cors from "cors";
import crypto from "crypto";

const app=express();
app.use(cors());
app.use(express.json());

const bookings=[];

app.get("/api/health",(req,res)=>{
  res.json({status:"OK",message:"Function Hall backend is running"});
});

app.get("/api/halls",(req,res)=>{
  res.json([
    {id:1,name:"Grand Palace Hall",capacity:800,rent:85000},
    {id:2,name:"Royal Celebration Hall",capacity:500,rent:60000},
    {id:3,name:"Pearl Mini Hall",capacity:300,rent:40000}
  ]);
});

app.get("/api/food",(req,res)=>{
  res.json([
    {id:1,type:"Veg",name:"Premium Veg Meals",price:300},
    {id:2,type:"Veg",name:"Paneer Special",price:350},
    {id:3,type:"Veg",name:"Veg Biryani",price:220},
    {id:4,type:"Non-Veg",name:"Chicken Biryani",price:330},
    {id:5,type:"Non-Veg",name:"Chicken 65",price:300},
    {id:6,type:"Non-Veg",name:"Mutton Special",price:450}
  ]);
});

app.post("/api/bookings",(req,res)=>{
  const {customer,phone,email,event,date,guests,hall,food,payment,total}=req.body;

  if(!customer||!phone||!email||!event||!date||!guests||!hall||!food){
    return res.status(400).json({message:"All required fields must be filled."});
  }

  const booking={
    bookingId:"FH-"+crypto.randomBytes(4).toString("hex").toUpperCase(),
    customer,phone,email,event,date,
    guests:Number(guests),hall:Number(hall),food:Number(food),
    payment,total:Number(total),
    paymentStatus:payment==="Cash at Hall"?"Pending":"Demo Paid"
  };

  bookings.push(booking);
  res.status(201).json(booking);
});

app.get("/api/bookings",(req,res)=>{
  res.json(bookings);
});

app.listen(5000,()=>console.log("Backend running at http://localhost:5000"));
